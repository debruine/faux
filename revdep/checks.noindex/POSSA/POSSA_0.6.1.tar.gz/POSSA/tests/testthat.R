library(testthat)
library(POSSA)

test_check("POSSA")
